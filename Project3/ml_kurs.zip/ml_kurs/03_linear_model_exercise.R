################### #
# Attach packages ----
################### #

library(tidyverse)
library(tidymodels)
library(readxl)

#################### #
# Exercise 1 - Import data ----
#################### #

# Insert the appropriate function to import the `houses.xlsx` dataset to R
houses_raw <- "<insert function>"("temp/houses.xlsx")

#################### #
# Exercise 2 - Transform data ----
#################### #

# Select variables for sqm, expense, total price, latitude, longitude, and municipality (kommune) from the houses_raw data set
# Also mutate a new column `log_sqm` which is the logarithm of `sqm` 
houses <- "<insert name of data set>" %>%
  select(sqm, expense, tot_price,
         "<insert name of latitude column>",
         "<insert name of longitude column>",
         "<insert name of municipality (kommune) column>") %>%
  mutate(kommune_name = fct_lump_n(kommune_name, 220),
         log_sqm      = "<insert log function>"(sqm))

#################### #
# Exercise 3 - Split data ----
#################### #

set.seed(42)

# Split 75 % of the data to the training set, and the rest to the test set
split <- initial_split(houses, "<insert name of split argument>" = "<insert split ratio>")
train <- "<insert function to select the training set>"(split)
test  <- "<insert function to select the test set>"(split)

#################### #
# Exercise 4 - Fit a linear model  ----
#################### #

# Set the target variable as the logarithm of total price and fit the linear model
model <- linear_reg() %>% 
  set_engine("lm") %>% 
  fit("<insert log of total price>" ~ ., data = "<insert correct data set>")

# Run the next line to view summary of fit
summary(model$fit)

#################### #
# Exercise 5 - Use model for predictions  ----
#################### #

# Use the fitted model to predict the total price for observations in the test set
# Remember to take the exponential of the .pred to return meaningful prediction values
# Also find the appropriate function to rename columns
model_preds <- 
  predict("<insert fitted model>", new_data = "<insert correct data set>") %>%
  bind_cols(test) %>% 
  mutate(.pred = "<insert appropriate function>"(.pred)) %>%     
  "<insert appropriate function>"(estimate     = .pred,
         truth        = tot_price) %>% 
  mutate(abs_dev      = abs(truth - estimate),
         abs_dev_perc = abs_dev/truth)

#################### #
# Exercise 6 - Evaluate model  ----
#################### #

# Evaluate the mean absolute percentage error of our linear model predictions
mape(data     = "<insert correct data set>",
     truth    = "<insert column that holds actual value>",
     estimate = "<insert column that holds predicted value>")

##################################### #
# Excerise 7 - Plot results ----
##################################### #

# Run the next lines to study the distribution of the percentage error
model_preds %>%
  ggplot(aes(x = abs_dev_perc)) +
  geom_histogram(fill = "dodgerblue3", color = "white") +
  theme_minimal() +
  labs(x = "Prosentvis feil",
       y = "Antall observasjoner") +
  scale_x_continuous(limits = c(0, 5), labels = scales::percent)

